package com.kumaran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
