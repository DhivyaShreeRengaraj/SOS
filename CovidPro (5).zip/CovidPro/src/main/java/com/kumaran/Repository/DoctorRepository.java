package com.kumaran.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kumaran.jpa.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
	
	@Query("from Doctor where doctorName=:doctorName AND password=:password")
	public Doctor validateDoctor(@Param(value="doctorName") String doctorName, @Param(value="password") String password);
	
	@Modifying
	@Query("update Doctor d set d.doctorStatus = :doctorStatus where d.doctorId = :doctorId")
	public void updateStatus(@Param(value = "doctorId") long doctorId, @Param(value = "doctorStatus") String doctorStatus);
	
	@Query("from Doctor where hospital_id=:hospitalId")
	public List<Doctor> getDoctorsInHospital(@Param(value = "hospitalId") long hospitalId);
}
