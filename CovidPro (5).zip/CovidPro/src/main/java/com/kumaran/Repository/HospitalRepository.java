package com.kumaran.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.kumaran.jpa.Hospital;

public interface HospitalRepository extends JpaRepository<Hospital, Long> {

	@Query("from Hospital where hospitalName=:hospitalName")
	public Hospital getHospitalByName(@Param(value="hospitalName")String hospitalName);
	
	@Modifying
	@Query("update Hospital h set bedAvailability=:bedAvailability-1 where h.hospitalId=:hospitalId")
	@Transactional
	void updateBedCount(@Param("bedAvailability") Integer bedAvailability, @Param("hospitalId") Long hospitalId);


	@Modifying
	@Query("update Hospital h set oxygenAvailability=:oxygenAvailability-1 where h.hospitalId=:hospitalId")
	@Transactional
	void updateOxygenCount(@Param("oxygenAvailability") Integer oxygenAvailability, @Param("hospitalId") Long hospitalId);
}
