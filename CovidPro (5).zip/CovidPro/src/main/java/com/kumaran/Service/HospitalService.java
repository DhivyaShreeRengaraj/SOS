package com.kumaran.Service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kumaran.Repository.DoctorRepository;
import com.kumaran.Repository.HospitalRepository;
import com.kumaran.jpa.Doctor;
import com.kumaran.jpa.Hospital;
import com.kumaran.jpa.User;

@Service
public class HospitalService {
	@Autowired
	HospitalRepository  hospitalRepo;
	@Autowired
	DoctorRepository doctorRepo;
	public List<Hospital> listAll()
	{
		return hospitalRepo.findAll();
	}
	public void save(Hospital hospital)
	{
		hospitalRepo.save(hospital);
	}
	public Hospital gethospital(Long hospitalId) {
		return hospitalRepo.findById(hospitalId).get();
	}
	
	public void delete(Long hospitalId) {
		hospitalRepo.deleteById(hospitalId);
	}
	public Hospital getHospitalByName(String hospitalName) {
		Hospital h = hospitalRepo.getHospitalByName(hospitalName);
		return h;
	}
	public boolean isHospitalByName(String hospitalName) {
		Hospital h = hospitalRepo.getHospitalByName(hospitalName);
		if (h == null) {
			return false;
		}
		return true;
	}
	public boolean isHospitalById(Long hospitalId) {
		return hospitalRepo.findById(hospitalId).isPresent();	
	}
	
	@Transactional
	public void editBedCount(Integer bedAvailability,Long hospitalId) {

		hospitalRepo.updateBedCount(bedAvailability, hospitalId);
	}
	@Transactional
	public void editOxygenCount(Integer oxygenAvailability,Long hospitalId) {

		hospitalRepo.updateOxygenCount(oxygenAvailability, hospitalId);
	}
}
