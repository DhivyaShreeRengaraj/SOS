package com.kumaran.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kumaran.Repository.DoctorRepository;
import com.kumaran.Repository.HospitalRepository;
import com.kumaran.jpa.Doctor;

@Service
public class DoctorService {
	@Autowired
	HospitalRepository  hospitalRepo;
	@Autowired
	DoctorRepository  doctorRepo;
	public List<Doctor> find()
	{
		return doctorRepo.findAll();
	}
	public void save(Doctor u)
	{
		doctorRepo.save(u);
	}
	public Doctor getdoctor(Long doctorId) {
		return doctorRepo.findById(doctorId).get();
	}
	
	public void delete(Long doctorId) {
		doctorRepo.deleteById(doctorId);
	}
	public boolean authenticateDoctor(String doctorName,String password){
		Doctor doctor = doctorRepo.validateDoctor(doctorName,password);
		if (doctor == null) {
			return false;
		}
		return true;
	}
	public Doctor retrieveDoctor(String doctorName,String password){
		Doctor doctor = doctorRepo.validateDoctor(doctorName,password);
		return doctor;
	}
	
	@Transactional
	public void updateStatus(Long doctorId,String doctorStatus) {
		doctorRepo.updateStatus(doctorId, doctorStatus);
	}
	
	public List<Doctor> getDoctorsInHospital(Long hospitalId){
		List<Doctor> list=doctorRepo.getDoctorsInHospital(hospitalId);
		return list;
	}
}
