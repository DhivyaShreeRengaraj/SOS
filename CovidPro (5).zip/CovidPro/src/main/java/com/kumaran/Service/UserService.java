package com.kumaran.Service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;

import com.kumaran.Repository.UserRepository;
import com.kumaran.jpa.User;

@Service
public class UserService {
	@Autowired
	UserRepository userRepo;

	public List<User> findAll() {
		return userRepo.findAll();
	}

	public void insertDetails(User u) {
		userRepo.save(u);
	}

	public User getUser(Long userid) {
		return userRepo.findById(userid).get();
	}

	public void delete(Long userid) {
		userRepo.deleteById(userid);
	}

	public boolean authenticateUser(String userName, String password) {
		User user = userRepo.validateUser(userName, password);
		if (user == null) {
			return false;
		}
		return true;
	}

	public User retrieveUser(String userName, String password) {
		User user = userRepo.validateUser(userName, password);
		return user;
	}
}
