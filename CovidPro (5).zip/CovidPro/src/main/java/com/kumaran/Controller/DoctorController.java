package com.kumaran.Controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kumaran.Service.DoctorService;
import com.kumaran.Service.HospitalService;
import com.kumaran.jpa.Doctor;
import com.kumaran.jpa.Hospital;
import com.kumaran.jpa.Login;

@Controller
public class DoctorController {

	@Autowired
	DoctorService service;
	@Autowired
	HospitalService hospitalService;

	@GetMapping("doctorlogin")
	public String showDoctorLogin(Model model) {
		Login login = new Login();
		model.addAttribute("login", login);
		return "doctorLogin";
	}

	@PostMapping("doctorlogin")
	public String doctorLogin(@ModelAttribute("login") Login login, BindingResult br, Model model) {
		if (br.hasErrors()) {
			return "doctorLogin";
		}
		else if (service.authenticateDoctor(login.getUsername(), login.getPassword()) == true) {
			Doctor d = service.retrieveDoctor(login.getUsername(), login.getPassword());
			model.addAttribute("doctor", d);
			return "forward:/doctorloginsuccess/" + d.getDoctorId();
		} else {
			String errMessage="Please Enter Valid USERNAME or PASSWORD";
			model.addAttribute("err",errMessage);
			return "doctorLogin";
		}
	}

	@RequestMapping("doctorloginsuccess/{doctorId}")
	public String doctorLoginSuccess(@PathVariable("doctorId") Long doctorId, Model model) {
		Doctor doctor = service.getdoctor(doctorId);
		model.addAttribute("doctor", doctor);

		return "doctorLoginSuccess";
	}

	@GetMapping("/doctorregister")
	public String showForm(Model model) {
		Doctor doctor = new Doctor();
		List<String> listStatus = Arrays.asList("Available","Busy", "Leave");
		model.addAttribute("listStatus",listStatus);
		doctor.setDoctorGender("Male");
		List<Hospital> listHospital=hospitalService.listAll();
		model.addAttribute("doctor", doctor);
		model.addAttribute("listHospital", listHospital);
		return "doctorRegistration";
	}

	@PostMapping("/adddoctor")
	public String submitForm(@Valid @ModelAttribute("doctor") Doctor doctor, BindingResult bindingResult, Model model) {
		System.out.println("Professing form...");

		if (bindingResult.hasErrors()) {
			List<String> listStatus = Arrays.asList("Available","Busy", "Leave");
			model.addAttribute("listStatus",listStatus);
			doctor.setDoctorGender("Male");
			List<Hospital> listHospital=hospitalService.listAll();
			model.addAttribute("doctor", doctor);
			model.addAttribute("listHospital", listHospital);
			return "doctorRegistration";
		}
		service.save(doctor);

		return "redirect:/doctorlogin";
	}

	@RequestMapping("/editdoctor/{doctorId}")
	public String edit(@PathVariable("doctorId") Long doctorId, Model model) {
		Doctor doctor = service.getdoctor(doctorId);
		List<Hospital> listHospital=hospitalService.listAll();
		model.addAttribute("listHospital", listHospital);
		model.addAttribute("doctor", doctor);
		return "doctorEditProfile";
	}

	@PostMapping("/savedoctorprofile")
	public String saveEdit(@Valid @ModelAttribute("doctor") Doctor doctor, BindingResult br, Model model) {
		service.save(doctor);
		return "redirect:/viewdoctor/" + doctor.getDoctorId();
	}

	@RequestMapping("/viewdoctor/{doctorId}")
	public String viewDoctor(@PathVariable("doctorId") Long doctorId, Model model) {
		Doctor doctor = service.getdoctor(doctorId);
		model.addAttribute("doctor", doctor);
		return "doctorViewProfile";
	}

	@RequestMapping("/editstatus/{doctorId}")
	public String editDoctorStatus(@PathVariable("doctorId") Long doctorId, Model model) {
		List<String> listStatus = Arrays.asList("Available","Busy", "Leave");
		model.addAttribute("listStatus",listStatus);
		Doctor doctor = service.getdoctor(doctorId);
		model.addAttribute("doctor", doctor);
		return "doctorEditStatus";
	}

	@PostMapping("/savedoctorstatus")
	public String saveEditStatus(@RequestParam("doctorId") Long doctorId,
			@RequestParam("doctorStatus") String doctorStatus, Model model) {
		service.updateStatus(doctorId, doctorStatus);
		Doctor doctor = service.getdoctor(doctorId);
		model.addAttribute("doctor", doctor);
		return "editStatusSuccess";
	}
	@RequestMapping("/viewalldoctors/{doctorId}")
	public String viewAllDoctors(@PathVariable("doctorId") Long doctorId,Model m) {
		Doctor doctor = service.getdoctor(doctorId);
		m.addAttribute("doctor", doctor);
		List<Doctor> list = service.find();
		m.addAttribute("doctorList", list);
		return "viewAllDoctors";
	}

	@GetMapping("/doctorlogout")
	public String doLogout(HttpSession session, Model model) {
		session.invalidate();
		Login login = new Login();
		model.addAttribute("login", login);
		return "doctorLogin";
	}

}
