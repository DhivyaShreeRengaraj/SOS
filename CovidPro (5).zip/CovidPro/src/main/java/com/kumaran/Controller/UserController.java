package com.kumaran.Controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kumaran.Service.DoctorService;
import com.kumaran.Service.HospitalService;
import com.kumaran.Service.UserService;
import com.kumaran.jpa.Doctor;
import com.kumaran.jpa.Hospital;
import com.kumaran.jpa.Login;
import com.kumaran.jpa.User;

@Controller
public class UserController {
	@Autowired
	UserService userService;
	@Autowired
	HospitalService hospitalService;
	@Autowired
	DoctorService doctorService;
	
	@GetMapping("userlogin")
	public String showUserLogin(Model model) {
		Login login =new Login();
		model.addAttribute("login",login);
		return "userLogin";
	}
	
	@PostMapping("userlogin")
	public String userLogin(@ModelAttribute("login") Login login, BindingResult br, Model model) {
		if (br.hasErrors()) {
			return "userLogin";
		}
		else if (userService.authenticateUser(login.getUsername(), login.getPassword()) == true) {
			User u = userService.retrieveUser(login.getUsername(), login.getPassword());
			model.addAttribute("user", u);
			return "forward:/userloginsuccess/" + u.getUserId();
		} 
		else
		{
			String errMessage="Please Enter Valid USERNAME or PASSWORD";
			model.addAttribute("err",errMessage);
			return "userLogin";
		}
		
	}
	
	@RequestMapping("userloginsuccess/{userId}")
	public String userLoginSuccess(@PathVariable("userId") Long userId, Model model) {
		User user = userService.getUser(userId);
		model.addAttribute("user", user);

		return "userLoginSuccess";
	}
	
	@GetMapping("/userRegister")
	public String showForm(Model model) {
		User user = new User();
		List<String> listBloodGroup = Arrays.asList("A+","A-", "B+","B-","O+","O-","AB+","AB-");
		model.addAttribute("listBloodGroup",listBloodGroup);
		model.addAttribute("user", user);
		return "userSignupPage";
	}
	
	@PostMapping("/userRegister")
	public String submitForm(@Valid @ModelAttribute("user") User user,BindingResult bindingResult,Model model) {
		System.out.println("Professing form...");
		
		if (bindingResult.hasErrors()) {
			List<String> listBloodGroup = Arrays.asList("A+","A-", "B+","B-","O+","O-","AB+","AB-");
			model.addAttribute("listBloodGroup",listBloodGroup);
			model.addAttribute("user", user);
			return "userSignupPage";
		}
		userService.insertDetails(user);
	
	 return "redirect:/userlogin";    
}    
 
	
@RequestMapping("/viewuser/{userId}")    
public String viewUser(@PathVariable("userId") Long userId, Model model) {
	User user = userService.getUser(userId);
	model.addAttribute("user", user);
	return "userViewProfile";
} 
     
@RequestMapping("/edituser/{userId}")
public String editUser(@PathVariable("userId") Long userId,Model model) {
	List<String> listBloodGroup = Arrays.asList("A+","A-", "B+","B-","O+","O-","AB+","AB-");
	model.addAttribute("listBloodGroup",listBloodGroup);
	User user = userService.getUser(userId);
	model.addAttribute("user", user);
	return "userEditProfile";
}

@PostMapping("/saveuserprofile")
public String saveEdit(@Valid @ModelAttribute("user") User user, BindingResult br, Model model) {
	userService.insertDetails(user);
	return "redirect:/viewuser/" + user.getUserId();
}

@RequestMapping("/viewhospitals/{userId}")
public String viewHospitals(@PathVariable("userId") Long userId,Model m) {
	User user = userService.getUser(userId);
	m.addAttribute("user", user);
	List<Hospital> list = hospitalService.listAll();
	m.addAttribute("hospitalList", list);
	return "userViewHospital";
}


@GetMapping("/userlogout")
public String doLogout(HttpSession session, Model model) {
	session.invalidate();
	Login login = new Login();
	model.addAttribute("login", login);
	return "userLogin";
}

@GetMapping("/updatebed/{hospitalId}/{userId}")
public String editbed(@PathVariable("hospitalId") Long hospitalId,@PathVariable("userId") Long userId,Model model) {
Hospital h1=hospitalService.gethospital(hospitalId);
if(h1.getBedAvailability() !=0 ) {
	hospitalService.editBedCount(h1.getBedAvailability(),hospitalId);
/*
* Hospital h2=service.gethospital(hospitalId); model.addAttribute("hospital",
* h2);
*/
	String msg="Registered successfully in "+h1.getHospitalName();
	model.addAttribute("msg",msg);
return "redirect:/bedregistersuccess/"+userId;
}
String err="No availabilities found. Try another hospital";
model.addAttribute("err",err);
return "redirect:/viewhospitals/"+userId;
}
@GetMapping("/updateoxygen/{hospitalId}/{userId}")
public String editoxygen(@PathVariable("hospitalId") Long hospitalId,@PathVariable("userId") Long userId,Model model) {
Hospital h1=hospitalService.gethospital(hospitalId);
if(h1.getOxygenAvailability() !=0 ) {
	hospitalService.editOxygenCount(h1.getOxygenAvailability(),hospitalId);
/*
* Hospital h2=service.gethospital(hospitalId); model.addAttribute("hospital",
* h2);
*/
	String msg="Registered successfully in "+h1.getHospitalName();
	model.addAttribute("msg",msg);
return "redirect:/bedregistersuccess/"+userId;
}
String err="No availabilities found. Try another hospital";
model.addAttribute("err",err);
return "forward:/viewhospitals/"+userId;
}

@RequestMapping("bedregistersuccess/{userId}")
public String bedregisterSuccess(@PathVariable("userId") Long userId, Model model) {
	User user = userService.getUser(userId);
	model.addAttribute("user", user);

	return "bedRegisterSuccess";
}

@RequestMapping("/viewallusers")
public String viewAllUsers(Model m) {
	List<User> list = userService.findAll();
	m.addAttribute("userList", list);
	return "viewAllUsers";
}
/*
 * @GetMapping("/getHospitalbyId") public String getHospitalById(Model model) {
 * Hospital hospital=new Hospital(); model.addAttribute("hospital",hospital);
 * return "getHospitalById"; }
 * 
 * @PostMapping("/getHospitalbyId") public String
 * getHospitalByIdResult(@RequestParam("id")Long id,Model model) { Hospital
 * hospital=service.gethospital(id); model.addAttribute("hospital",hospital);
 * return "getHospitalByIdResult"; }
 */
//@RequestMapping("/viewalldoctor/{userId}")
//public String viewAllDoctors(@PathVariable("userId") Long userId,Model m) {
//	User user = userService.getUser(userId);
//	m.addAttribute("user", user);
//	List<Doctor> list = doctorService.find();
//	m.addAttribute("doctorList", list);
//	return "viewAllDoctors";
//}




  @GetMapping("/getdoctorsinhospitaluser/{userId}") 
  public String getDoctors(@PathVariable("userId") Long userId,Model m)
  { 
	  User user = userService.getUser(userId);
	  m.addAttribute("user", user); 
	  Hospital hospital=new Hospital(); 
	  m.addAttribute("hospital",hospital);
	  List<Hospital> listHospital=hospitalService.listAll();
	  m.addAttribute("listHospital", listHospital); 
	  List<Doctor> list = doctorService.find();
  m.addAttribute("doctorList", list); 
  //return"getDoctorsByHospitalUser/{hospitalId}/{userId}"; 
  return "getDoctorByHospitalUser"; }
  
  @PostMapping("getdoctorsinhospitall/{userId}")
  public String getDoctorsResult(Long hospitalId,@PathVariable("userId") Long userId,Model m) 
  {
  User user = userService.getUser(userId);
  m.addAttribute("user", user); 
  List<Hospital> listHospital=hospitalService.listAll();
  m.addAttribute("listHospital",listHospital); 
//  Long hospitalId=hospital.getHospitalId(); 
  List<Doctor> list=doctorService.getDoctorsInHospital(hospitalId);
  m.addAttribute("doctorList",list); 
  return "getDoctorByHospitalUser";
  }
 
//
//@GetMapping("//{userId}")
//public String userSearchCity(@PathVariable Integer userId, Model model) {
//	
//	model.addAttribute("userId", userId);
//	return "userGetcenterbyCity";
//}
//
//
//@PostMapping("/userlistCenter/{userId}")
//public ModelAndView getCenterCity(@PathVariable Integer userId, String city) {
//	
//	System.out.println(city);
//	
//	System.out.println("============================="+userId);
//	
//List<VaccinationCenter> centerList=	 vaccinationCenterService.getVaccinationCenterByCityName(city);
//
//System.out.println(centerList);
//
//  if(centerList.isEmpty()) {
//	  return new ModelAndView("userGetcenterbyCity","message","Invalid city !!");
//  }else {
//	  
//	  ModelAndView mv= new ModelAndView("userGetCenterResult","center",centerList);
//	  mv.addObject("userId",userId);
//	  return mv;
//  }
//  	
//	
//}
}

