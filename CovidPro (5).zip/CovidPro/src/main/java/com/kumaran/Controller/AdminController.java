package com.kumaran.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.kumaran.Service.DoctorService;
import com.kumaran.Service.HospitalService;
import com.kumaran.jpa.Doctor;
import com.kumaran.jpa.Hospital;
import com.kumaran.jpa.Login;

@Controller
public class AdminController {
	@Autowired
	HospitalService service;
	@Autowired
	DoctorService doctorService;

	@RequestMapping("/")
	public String Welcome() {
		return "home";
	}

	@GetMapping("/logout")
	public String doLogout(HttpSession session, Model model) {
		session.invalidate();
		Login login = new Login();
		model.addAttribute("login", login);
		return "adminLogin";
	}

	@GetMapping("/adminLogin")
	public String AdminLogin(Model model) {
		Login login = new Login();
		model.addAttribute("login", login);
		return "adminLogin";
	}

	@PostMapping("/adminDashboard")
	public String goToAdminDashboard(@Valid @ModelAttribute("login") Login login, BindingResult bindingResult,
			Model model) {
		System.out.println(login.getUsername());
		System.out.println(login.getPassword());
		if (bindingResult.hasErrors()) {
			return "adminLogin";
		}
		else if (login.getUsername().equals("Admin") && login.getPassword().equals("123"))
			return "adminDashboard";
		else {
			String errMessage="Please Enter Valid USERNAME or PASSWORD";
			model.addAttribute("err",errMessage);
			return "adminLogin";
		}
	}

	@GetMapping("/admindashboard")
	public String backToDashboard() {
		return "adminDashboard";
	}

	@GetMapping("/addhospital")
	public String showForm(Model model) {
		Hospital hospital = new Hospital();
		model.addAttribute("hospital", hospital);
		return "hospitalRegistration";
	}

	@PostMapping("/addhospital")
	public String submitForm(@Valid @ModelAttribute("hospital") Hospital hospital, BindingResult bindingResult,
			Model model) {
		System.out.println("Professing form...");

		if (bindingResult.hasErrors()) {
			return "hospitalRegistration";
		}
		service.save(hospital);
		return "redirect:/viewhospital";
	}

	@GetMapping("/selectHospitalByName")
	public String getHospitalByName(Model model) {
		Hospital hospital = new Hospital();
		model.addAttribute("hospital", hospital);
		return "getHospitalByName";
	}

	@PostMapping("/getHospital")
	public String getHospitalByIdResult(@RequestParam("id") Long id, Model model) {
		
		if(service.isHospitalById(id)==true) {
			Hospital hospital = service.gethospital(id);
		model.addAttribute("hospitalRes", hospital);
		return "getHospitalByName";
		}
		else {
			Hospital hospital = new Hospital();
			model.addAttribute("hospital", hospital);
			String err="Enter valid hospital ID";
			model.addAttribute("err",err);
			return "getHospitalByName";
		}
	}

	
	@PostMapping("/getHospitalByName")
	public String getHospitalByNameResult(@RequestParam("name") String name, Model model) {
		if(service.isHospitalByName(name)) {
		Hospital hospital = service.getHospitalByName(name);
		model.addAttribute("hospitalRes", hospital);
		return "getHospitalByName";
		}
		else {
			String err="Enter valid hospital name";
			model.addAttribute("errMsg", err);
		return "getHospitalByName";
		}
	}

	@GetMapping("/edithospital/{hospitalId}")
	public String edit(@PathVariable("hospitalId") Long hospitalId, Model model) {
		Hospital hospital = service.gethospital(hospitalId);
		model.addAttribute("hospital", hospital);
		return "editHospitalForm";
	}

	@PostMapping("/save")
	public String saveEdit(@Valid @ModelAttribute("hospital") Hospital hospital, BindingResult br, Model model) {
		if (br.hasErrors()) {
			model.addAttribute("hospital", hospital);
			return "editHospitalForm";
		}
		service.save(hospital);
		return "redirect:/viewhospital";
	}

	@RequestMapping("/viewhospital")
	public String viewhos(Model m) {
		List<Hospital> list = service.listAll();
		m.addAttribute("hospitalList", list);
		return "hospitalRegisterSuccess";
	}

	@RequestMapping("/deletehospital/{hospitalId}")
	public String delete(@PathVariable("hospitalId") Long hospitalId, Model model) {
		service.delete(hospitalId);
		return "redirect:/viewhospital";
	}

	
	@RequestMapping("/getdoctorsinhospital")
	public String getDoctors(Model m) {
		Hospital hospital=new Hospital();
		m.addAttribute("hospital",hospital);
		List<Hospital> listHospital=service.listAll();
		m.addAttribute("listHospital", listHospital);
		List<Doctor> list = doctorService.find();
		m.addAttribute("doctorList", list);
		return "getDoctorsInHospital"; 
	}
	@PostMapping("/getdoctorsinhospital")
	public String getDoctors(@ModelAttribute("hospital") Hospital hospital,Model m) {
		List<Hospital> listHospital=service.listAll();
		m.addAttribute("listHospital", listHospital);
		Long hospitalId=hospital.getHospitalId();
		List<Doctor> list=doctorService.getDoctorsInHospital(hospitalId);
		m.addAttribute("doctorList",list);
		return "getDoctorsInHospital";  
	}
}
