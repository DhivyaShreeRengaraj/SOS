package com.kumaran.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long userId;
	@Size(min = 3, max = 50)
	private String userName;

	@NotBlank
	@Email(message = "Please enter a valid e-mail address")
	private String email;

	@NotBlank
	private String bloodGroup;
	@NotBlank
	@Size(max = 10)
	private String phoneNumber;
	@NotBlank
	@Size(max = 100)
	private String address;
	@NotBlank
	@Size(min=3, max=15)
	private String password;
	
	public User(Long userId, @Size(min = 3, max = 50) String userName,
			@NotBlank @Email(message = "Please enter a valid e-mail address") String email, @NotBlank String bloodGroup,
			@NotBlank @Size(max = 10) String phoneNumber, @NotBlank @Size(max = 100) String address,
			@NotBlank @Size(min = 3, max = 15) String password) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.email = email;
		this.bloodGroup = bloodGroup;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.password = password;
	}
	public User() {
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
