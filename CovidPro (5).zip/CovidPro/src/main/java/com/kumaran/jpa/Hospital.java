package com.kumaran.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//import com.sun.istack.NotNull;

@Entity
public class Hospital { 
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long hospitalId;
	@NotBlank(message = "This field is Mandatory")
	@Size(min=2, max=20, message = "Length of the name must be between 2 and 20")
	String hospitalName;
	@NotBlank(message = "This field is Mandatory")
	@Size(min=2, max=20, message = "Length of the address must be between 2 and 50")
	String hospitalAddress;
	@NotNull(message = "This field is Mandatory")
	@Min(value = 600000)
	@Max(value = 649999)
	int hospitalPincode;
	@NotNull
	int bedAvailability;
	@NotNull
	int oxygenAvailability;
	//@OneToMany(cascade = CascadeType.ALL, mappedBy="hospital")
	
	//List<Doctor> listOfDoctors=new ArrayList<>();
	public Hospital(Long hospitalId, @NotBlank(message = "This field is Mandatory") String hospitalName,
			@NotBlank(message = "This field is Mandatory") String hospitalAddress, @NotNull int hospitalPincode,
			@NotNull int bedAvailability, @NotNull int oxygenAvailability) {
		super();
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.hospitalAddress = hospitalAddress;
		this.hospitalPincode = hospitalPincode;
		this.bedAvailability = bedAvailability;
		this.oxygenAvailability = oxygenAvailability;
		//this.listOfDoctors = listOfDoctors;
	}
	public Hospital() {
	}
	public Long getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(Long hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getHospitalAddress() {
		return hospitalAddress;
	}
	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}
	public int getHospitalPincode() {
		return hospitalPincode;
	}
	public void setHospitalPincode(int hospitalPincode) {
		this.hospitalPincode = hospitalPincode;
	}
	public int getBedAvailability() {
		return bedAvailability;
	}
	public void setBedAvailability(int bedAvailability) {
		this.bedAvailability = bedAvailability;
	}
	public int getOxygenAvailability() {
		return oxygenAvailability;
	}
	public void setOxygenAvailability(int oxygenAvailability) {
		this.oxygenAvailability = oxygenAvailability;
	}

	@Override
	public String toString() {
		return "Hospital [hospitalId=" + hospitalId + ", hospitalName=" + hospitalName + ", hospitalAddress="
				+ hospitalAddress + ", hospitalPincode=" + hospitalPincode + ", bedAvailability=" + bedAvailability
				+ ", oxygenAvailability=" + oxygenAvailability  + "]";
	}
	
	
}
