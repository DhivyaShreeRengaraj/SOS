package com.kumaran.jpa;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Entity
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long doctorId;
	@NotBlank
	String doctorName;
	@NotBlank
    String doctorQualification;
	@NotBlank
	String doctorAge;
	@NotEmpty
	String doctorGender;
	@NotBlank
	String doctoraddress;
	@NotBlank
	String password;

	String doctorStatus;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="hospitalId")
	Hospital hospital;
	public Doctor(Long doctorId, @NotBlank String doctorName, @NotBlank String doctorQualification,
			@NotBlank String doctorAge, @NotEmpty String doctorGender, @NotBlank String doctoraddress,
			@NotBlank String password, String doctorStatus, Hospital hospital) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorQualification = doctorQualification;
		this.doctorAge = doctorAge;
		this.doctorGender = doctorGender;
		this.doctoraddress = doctoraddress;
		this.password = password;
		this.doctorStatus = doctorStatus;
		this.hospital = hospital;
	}
	
	public Doctor() {
	}

	public Long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Long doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorQualification() {
		return doctorQualification;
	}
	public void setDoctorQualification(String doctorQualification) {
		this.doctorQualification = doctorQualification;
	}
	public String getDoctorAge() {
		return doctorAge;
	}
	public void setDoctorAge(String doctorAge) {
		this.doctorAge = doctorAge;
	}
	public String getDoctorGender() {
		return doctorGender;
	}
	public void setDoctorGender(String doctorGender) {
		this.doctorGender = doctorGender;
	}
	public String getDoctoraddress() {
		return doctoraddress;
	}
	public void setDoctoraddress(String doctoraddress) {
		this.doctoraddress = doctoraddress;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDoctorStatus() {
		return doctorStatus;
	}
	public void setDoctorStatus(String doctorStatus) {
		this.doctorStatus = doctorStatus;
	}
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
}
